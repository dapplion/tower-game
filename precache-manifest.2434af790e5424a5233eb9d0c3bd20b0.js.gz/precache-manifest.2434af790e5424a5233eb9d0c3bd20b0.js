self.__precacheManifest = [
  {
    "revision": "06e3bf8accef6c6a6c2a37d2f5df6ad7",
    "url": "/tower-game/static/media/win.06e3bf8a.gif"
  },
  {
    "revision": "ebfe137658086ad5cbbf",
    "url": "/tower-game/static/js/runtime~main.ebfe1376.js"
  },
  {
    "revision": "18a1333b51cd27139bfa",
    "url": "/tower-game/static/js/main.18a1333b.chunk.js"
  },
  {
    "revision": "43b93a6c69fc26774a6d",
    "url": "/tower-game/static/js/2.43b93a6c.chunk.js"
  },
  {
    "revision": "18a1333b51cd27139bfa",
    "url": "/tower-game/static/css/main.faa73503.chunk.css"
  },
  {
    "revision": "f85f079d74a832f204deb0f27c840a08",
    "url": "/tower-game/index.html"
  }
];